import { SSEProps } from "./index";
export interface DiscordProps extends SSEProps {
    /**
     * Discord OAuth Client ID
     */
    clientId?: string;
    /**
     * Discord OAuth Client Secret
     */
    clientSecret?: string;
    /**
     * Discord OAuth Scope
     * @default []
     * @see https://discord.com/developers/docs/topics/oauth2#shared-resources-oauth2-scopes
     * @example ['identify', 'email']
     * Without the identify scope the user will not be returned.
     */
    scope?: string[];
    /**
     * Require email from user, adds the ['email'] scope if not present.
     * @default false
     */
    emailRequired?: boolean;
    /**
     * Require profile from user, adds the ['identify'] scope if not present.
     * @default true
     */
    profileRequired?: boolean;
    /**
     * Discord OAuth Authorization URL
     * @default 'https://discord.com/oauth2/authorize'
     */
    authorizationURL?: string;
    /**
     * Discord OAuth Token URL
     * @default 'https://discord.com/api/oauth2/token'
     */
    tokenURL?: string;
    /**
     * Discord OAuth User fetch URL
     * @default 'https://discord.com/api/users/@me'
     */
    userUrl?: string;
    /**
     * Extra authorization parameters to provide to the authorization URL
     * @see 'https://discord.com/developers/docs/topics/oauth2#authorization-code-grant'
     * @example { allow_signup: 'true' }
     */
    authorizationParams?: Record<string, string>;
}
export interface DiscordProfile extends Record<string, any> {
    /** the user's id (i.e. the numerical snowflake) */
    id?: string;
    /** the user's username, not unique across the platform */
    username?: string;
    /** the user's Discord-tag */
    discriminator?: string;
    /** the user's display name, if it is set  */
    global_name?: string | null;
    /**
     * the user's avatar hash:
     * https://discord.com/developers/docs/reference#image-formatting
     */
    avatar?: string | null;
    /** whether the user belongs to an OAuth2 application */
    bot?: boolean;
    /**
     * whether the user is an Official Discord System user (part of the urgent
     * message system)
     */
    system?: boolean;
    /** whether the user has two factor enabled on their account */
    mfa_enabled?: boolean;
    /**
     * the user's banner hash:
     * https://discord.com/developers/docs/reference#image-formatting
     */
    banner?: string | null;
    /** the user's banner color encoded as an integer representation of hexadecimal color code */
    accent_color?: number | null;
    /**
     * the user's chosen language option:
     * https://discord.com/developers/docs/reference#locales
     */
    locale?: string;
    /** whether the email on this account has been verified */
    verified?: boolean;
    /** the user's email */
    email?: string | null;
    /**
     * the flags on a user's account:
     * https://discord.com/developers/docs/resources/user#user-object-user-flags
     */
    flags?: number;
    /**
     * the type of Nitro subscription on a user's account:
     * https://discord.com/developers/docs/resources/user#user-object-premium-types
     */
    premium_type?: number;
    /**
     * the public flags on a user's account:
     * https://discord.com/developers/docs/resources/user#user-object-user-flags
     */
    public_flags?: number;
    /** undocumented field; corresponds to the user's custom nickname */
    display_name?: string | null;
    /**
     * undocumented field; corresponds to the Discord feature where you can e.g.
     * put your avatar inside of an ice cube
     */
    avatar_decoration?: string | null;
    /**
     * undocumented field; corresponds to the premium feature where you can
     * select a custom banner color
     */
    banner_color?: string | null;
    /** undocumented field; the CDN URL of their profile picture */
    image_url?: string;
}
export declare enum DiscordScopes {
    IDENTIFY = "identify",
    EMAIL = "email",
    GUILDS = "guilds",
    GUILDS_JOIN = "guilds.join",
    GDM_JOIN = "gdm.join",
    MESSAGES_READ = "messages.read",
    RPC = "rpc",
    RPC_NOTIFICATIONS_READ = "rpc.notifications.read",
    RPC_VOICE_READ = "rpc.voice.read",
    RPC_VOICE_WRITE = "rpc.voice.write",
    RPC_ACTIVITIES_WRITE = "rpc.activities.write",
    BOT = "bot",
    WEBHOOK_INCOMING = "webhook.incoming",
    APPLICATIONS_BUILDS_UPLOAD = "applications.builds.upload",
    APPLICATIONS_BUILDS_READ = "applications.builds.read",
    APPLICATIONS_STORE_UPDATE = "applications.store.update",
    APPLICATIONS_ENTITLEMENTS = "applications.entitlements",
    ACTIVITIES_READ = "activities.read",
    ACTIVITIES_WRITE = "activities.write",
    RELATIONSHIPS_READ = "relationships.read"
}
